<?php

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
        header('Location: ../login.php');
        die();
    }

    function logout(){
        if (session_status() == PHP_SESSION_ACTIVE){
            session_unset();
            session_destroy();
            header('Location: ../login.php');
            die();
        }
    }

    if (isset($_GET['logout'])) {
        logout();
    }

	error_reporting(0);
	if (!isset($_FILES['files'])) {
		echo "";
	} else {
		$target_dir = "../verification/";
		$target_file = $target_dir . basename($_FILES["files"]["name"]);
		$uploadOk = 1;
		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

		if (file_exists($target_file)) {
			$errorUpload = "File dengan nama ". basename($_FILES["files"]["name"]). " sudah ada.";
			$_SESSION['errorUpload'] = $errorUpload;
			header("Location: index.php");
			$uploadOk = 0;
			die();
		}
		if ($_FILES["files"]["size"] > 700) {
			$errorUpload = "Ukuran terlalu besar, ukuran yang diperbolehkan adalah <= 700 byte";
			$_SESSION['errorUpload'] = $errorUpload;
			header("Location: index.php");
			$uploadOk = 0;
			die();
		}
		if($imageFileType != "txt" ) {
			$errorUpload = "Type file yang diperbolehkan hanya .txt";
			$_SESSION['errorUpload'] = $errorUpload;
			header("Location: index.php");	
			$uploadOk = 0;
			die();
		}
		$data = file_get_contents($_FILES["files"]["tmp_name"]);
		$blacklist = "/(?:eval|assert|system|shell_exec|strrev|str_replace|exec|popen|proc_open|passthru|curl_exec|curl_multi_exec|parse_ini_file|show_source|base64_decode|gzinflate|gzuncompress|gzdecode|assert|`|include|require|file_get_contents|fwrite|hidden|backdoor)/i";
		if (preg_match($blacklist, strtolower($data), $match)) {	
			$errorUpload = "File yang kamu upload terdeteksi virus";
			$_SESSION['errorUpload'] = $errorUpload;
			header("Location: index.php");
			$uploadOk = 0;
			die();
		} else {
			$uploadOk = 1;
		}

		if ($uploadOk == 0) {
			$errorUpload = "Maaf, file kamu tidak berhasil di upload";
			header("Location: index.php");
			$_SESSION['errorUpload'] = $errorUpload;
			die();
		} else {
			if (move_uploaded_file($_FILES["files"]["tmp_name"], $target_file)) {
				$errorUpload = "File berhasil di upload ke ". $target_dir . basename( $_FILES["files"]["name"]. ". Verifikasi membutuhkan waktu 1x24 jam agar artikel di dapat publish");
				$successUpload = "green";
				$_SESSION['errorUpload'] = $errorUpload;
				$_SESSION['successUpload'] = $successUpload;
			} else {
				$errorUpload = "Terjadi error ketika upload file";
				$_SESSION['errorUpload'] = $errorUpload;
				header("Location: index.php");
				die();
			}
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Upload Artikel Baru</title>
	<link rel="stylesheet" href="/assets/css/bootstrap.min.css">
	<link rel="icon" type="image/x-icon" href="../favicon.ico?v=2">
	<link rel="icon" type="image/x-icon" href="../favicon.ico">
	<style>
        body,h1,h2,h3,li,p,ul{margin:0;padding:0}body{font-family:Arial,sans-serif;background-color:#f0f0f0}.navbar{background-color:#1c6da8!important}.container{max-width:1200px;margin:0 auto;padding:10px}.title{font-size:24px;margin:20px 0;text-align:center;font-weight:700}.content{background-color:#fff;padding:20px;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}.file-upload{width:100%;border:1px solid #ccc;border-radius:4px;padding:10px;margin-bottom:10px}.file-upload-btn{border:none;background-color:#fff;color:#ccc;font-size:16px;cursor:pointer}.file-upload-btn:hover{color:#fff;background-color:#ccc}.file-upload-filename{font-size:12px}.btn,.form-control{border-radius:4px}.center-block{display:flex;align-items:center;justify-content:center}
    </style>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="../index.php">Reddtikel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/uploads/" style="color: #ffffff !important">Upload Article</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-danger" href="index.php?logout=1" style="color: #ffffff !important">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="content">
            <h2 class="title">Upload Artikel Baru</h2>
			<?php if(isset($_SESSION['errorUpload'])): ?>
				<?php if (isset($_SESSION['successUpload'])): ?>
					<p style="color: green; text-align: center;"><?php echo $_SESSION['errorUpload']; ?></p>
					<?php unset($_SESSION['errorUpload']); ?>
					<?php unset($_SESSION['successUpload']); ?>
				<?php else: ?>
					<p style="color: red; text-align: center;"><?php echo $_SESSION['errorUpload']; ?></p>
					<?php unset($_SESSION['errorUpload']); ?>
					<?php endif; ?>
				<?php unset($_SESSION['errorUpload']); ?>
            <?php endif; ?>
            <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="file-upload">Pilih File</label>
                    <input type="file" class="form-control" id="files" name="files">
                </div>
				<div class="center-block">
					<button type="submit" class="btn btn-primary">Upload</button>
				</div>
            </form>
        </div>
    </div>
</body>
</html>
