<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    if(isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        if($username === 'catineshumen' && $password === '1nw4@rv0bc4%8162') {
            $_SESSION['loggedIn'] = true;
            header('Location: index.php');
            exit();
        } else {
            $errorMessage = 'Wrong username or password.';
        }
    }

    if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
        header('Location: index.php');
        exit();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login to Reddtikel</title>
    <link rel="stylesheet" href="/assets/css/style.css"> 
    <!-- <link rel="icon" type="image/png" href="favicon-16x16.png"> -->
    <link rel="icon" type="image/x-icon" href="favicon.ico?v=2">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body>
    <main>
        <div class="container">
            <h2>Login</h2>
            <!--
                catineshumen:1nw4@rv0bc4%8162
            -->
            <?php if(isset($errorMessage)): ?>
                <p style="color: red;"><?php echo $errorMessage; ?></p>
            <?php endif; ?>
            <form method="post" action="login.php">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username"><br><br>
                <label for="password">Password:</label> 
                <input type="password" id="password" name="password"><br><br>
                <button disabled type="submit">Login</button>
            </form>
        </div>
    </main>
    <footer>
        <p style="text-align: center;">Reddtikel &copy; 2023</p>
    </footer>
</body>
</html>
