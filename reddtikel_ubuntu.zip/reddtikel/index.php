<?php
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    if(!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
        header('Location: login.php');
        exit();
    }

    function logout(){
        if (session_status() == PHP_SESSION_ACTIVE){
            session_unset();
            session_destroy();
            header('Location: login.php');
            exit();
        }
    }

    if (isset($_GET['logout'])) {
        logout();
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Reddtikel Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css">
    <link rel="icon" type="image/x-icon" href="favicon.ico?v=2">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <style>
        .footer,.title{text-align:center}body,h1,h2,h3,li,p,ul{margin:0;padding:0}body{font-family:Arial,sans-serif;background-color:#f0f0f0}.navbar{background-color:#1c6da8!important}.container{max-width:1200px;margin:0 auto;padding:10px}.title{font-size:24px;margin:20px 0;font-weight:700}.content{background-color:#fff;padding:20px;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,.1)}.footer,.table th{background-color:#1c6da8;color:#fff}.table{width:100%;border-collapse:collapse;margin-bottom:20px}.table td,.table th{padding:8px;text-align:left}.table tbody tr:nth-child(odd){background-color:#f2f2f2}.footer{position:relative;bottom:0;width:100%;padding:10px}
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container top">
            <a class="navbar-brand" href="index.php">Reddtikel</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/uploads/" style="color: #ffffff !important">Upload Article</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-danger" href="index.php?logout=1" style="color: #ffffff !important">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="content">
        <?php
            $articles = [
                [
                    'judul' => 'Apa itu LSO Kaliber?',
                    'pemilik' => 'LSO Kaliber',
                    'tanggal' => 'Senin, 20 Maret 2023 - 13:01 WIB',
                    'halaman' => 'LSO-Kaliber.html',
                ],
                [
                    'judul' => 'Sejarah Kali Linux',
                    'pemilik' => 'ChatGPT-3.5',
                    'tanggal' => 'Selasa, 4 Juli 2023 - 10:10 WIB',
                    'halaman' => 'Kali-Linux.html',
                ],
                [
                    'judul' => 'Serangan Ransomware',
                    'pemilik' => 'John Y',
                    'tanggal' => 'Rabu, 5 Juli 2023 - 07:00 WIB',
                    'halaman' => 'Ransomware.html',
                ],
                [
                    'judul' => 'Pentingnya Enkripsi Data',
                    'pemilik' => 'Wahidun Satu',
                    'tanggal' => 'Sabtu, 6 Mei 2023 - 00:05 WIB',
                    'halaman' => 'Enkripsi-Data.html',
                ],
                [
                    'judul' => 'Serangan Phishing',
                    'pemilik' => 'Carok',
                    'tanggal' => 'Sabtu, 29 April 2023 - 01:20 WIB',
                    'halaman' => 'Serangan-Phishing.html',
                ],
                [
                    'judul' => 'Keamanan Internet of Things (IOT)',
                    'pemilik' => 'Beliau',
                    'tanggal' => 'Minggu, 30 April 2023 - 07:55 WIB',
                    'halaman' => 'Keamanan-Internet-of-Things-(IOT).html',
                ],
                [
                    'judul' => 'Keamanan Kata Sandi',
                    'pemilik' => 'Gigs',
                    'tanggal' => 'Senin, 24 Juli 2023 - 11:23 WIB',
                    'halaman' => 'Keamanan-Kata-Sandi:-Langkah-Pertama-dalam-Proteksi-Data.html',
                ],
            ];

            if (isset($_GET['page'])) {
                $title = htmlentities(pathinfo($_GET['page'], PATHINFO_FILENAME));
                $title = str_replace("-", " ", $title);
                echo "<h2 class=\"title\">" . $title . "</h2>";
                include('article/' . $_GET['page']);
            } else {
                echo '<h2 class="title">Daftar Artikel</h2>';
                echo '<article>';
                echo '<table class="table">';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Judul Artikel</th>';
                echo '<th>Tanggal Rils</th>';
                echo '<th>Author</th>';
                echo '<th></th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';
                foreach ($articles as $article) {
                    echo '<tr>';
                    echo '<td>' . $article['judul'] . '</td>';
                    echo '<td>' . $article['tanggal'] . '</td>';
                    echo '<td>' . $article['pemilik'] . '</td>';
                    echo '<td><a class="btn btn-success" href="?page=' . $article['halaman'] . '">Baca</a></td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
                echo '</article>';
            }
        ?>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Reddtikel. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
