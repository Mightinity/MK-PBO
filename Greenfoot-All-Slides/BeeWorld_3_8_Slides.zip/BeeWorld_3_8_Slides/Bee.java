import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bee extends Actor
{
    private GreenfootImage image1;
    private GreenfootImage image2;
    private int score;
    private int lives;
    
    public Bee(){
        image1 = new GreenfootImage("bee1.png");
        image2 = new GreenfootImage("bee2.png");
        setImage(image1);
        score = 0;
        lives = 3;
    }//end constructor
    
    /**
     * Act - do whatever the Bee wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        animateBee();
        handleMovement();
        turnAtEdge();
        catchFly();
        caughtBySpider();
    }//end method act

    /**
     * caughtBySpider - Resets the location of the Bee and reduces the lives variable by 1
     */
    private void caughtBySpider(){
        if(isTouching(Spider.class)){
            setLocation(20,20);
            lives--;
            if(lives<0){
                endGame();
            }//endif
        }//endif
    }//end method caughtBySpider
    
    /**
     * endGame - ends the game
     */
    private void endGame(){
        Greenfoot.stop();
    }//end method endGame
    
    /**
     * animateBee - changes the images for the bee
     */
    private void animateBee(){
        if(getImage()==image1)
            setImage(image2);
        else
            setImage(image1);    
        //endif   
    }//end method animateBee
    
    /**
     * turnAtEdge - moves the object if it is at the edge
     */
    private void turnAtEdge(){
        if(atRightEdge()){
            setLocation(6, getY());
        }
        else if(atBottomEdge()){
            setLocation(getX(), 6);
        }
        else if(atLeftEdge()){
            setLocation(getWorld().getWidth()-20, getY());
        }
        else if(atTopEdge()){
            setLocation(getX(), getWorld().getHeight()-20);
        }//endif
    }//end method turnAtEdge
    
    /**
     * handleMovement - moves the object forward a given amount
     */
    private void handleMovement(){
        move(1);
    }//end method handleMovement
    
    /**
     * catchFly2 - if the Bee touches a fly the fly is removed
     */
    private void catchFly2(){
        Actor fly = getOneIntersectingObject(Fly.class);
        if(fly != null){
            getWorld().removeObject(fly);
            Greenfoot.playSound("slurp.wav");
        }//endif
    }//end method catchFly2
    
    /**
     * catchFly - if the Bee touches a fly the fly is removed
     * A souond is played, the score increased and a new fly is added to the game
     */
    private void catchFly(){
        if(isTouching(Fly.class)){
            removeTouching(Fly.class);
            Greenfoot.playSound("slurp.wav");
            score++;
            getWorld().addObject(new Fly(), Greenfoot.getRandomNumber(getWorld().getWidth()),
                                            Greenfoot.getRandomNumber(getWorld().getHeight()));
        }//endif
    }//end method catchFly
    
    /**
     * updateScore - Increases the score and displayes the new score on screen
     */
    private void updateScore(){
        score++;
        getWorld().showText("Score : " + score, 60, 390);
    }//end method updateScore
    
    /**
     * atLeftEdge - Test if we are close to the left edge of the world
     * Return true if the object is
     */
    private boolean atLeftEdge()
    {
        if(getX() < 6)
            return true;
        else
            return false;
        //endif    
    }//end method atLeftEdge  
    
    /**
     * atTopEdge - Test if we are close to the top edge of the world
     * Return true if the object is
     */
    private boolean atTopEdge()
    {
        if(getY() < 6)
            return true;
        else
            return false;
        //endif    
    }//end method atTopEdge  
    
    /**
     * atBottomEdge - Test if we are close to the bottom edge of the world
     * Return true if the object is
     */
    private boolean atBottomEdge()
    {
        if(getY() > getWorld().getHeight() - 20)
            return true;
        else
            return false;
        //endif    
    }//end method atBottomEdge    
    
    /**
     * atRightEdge - Test if we are close to the right edge of the world
     * Return true if the object is
     */
    private boolean atRightEdge()
    {
        if(getX() > getWorld().getWidth() - 20)
            return true;
        else
            return false;
        //endif    
    }//end method atRightEdge
}//end class Bee
