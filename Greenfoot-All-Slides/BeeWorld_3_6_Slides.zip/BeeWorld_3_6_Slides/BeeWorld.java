import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BeeWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BeeWorld extends World
{

    /**
     * Constructor for objects of class BeeWorld.
     * 
     */
    public BeeWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spider spider = new Spider();
        addObject(spider,95,90);
        Bee bee = new Bee();
        addObject(bee,299,181);
        Fly fly = new Fly();
        addObject(fly,469,307);
        Bee bee2 = new Bee();
        addObject(bee2,87,235);
        Bee bee3 = new Bee();
        addObject(bee3,483,76);
        Bee bee4 = new Bee();
        addObject(bee4,363,306);
        bee2.turn(90);
        bee3.turn(-90);
        bee4.turn(180);
    }
}
